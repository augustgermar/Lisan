#!/usr/bin/env python3
"""Deterministic helper for YourWeb and cPanel operations."""

from __future__ import annotations

import argparse
import json
import os
import socket
import ssl
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


DEFAULT_AUDIT_PATH = Path(os.getenv("YOURWEB_AUDIT_PATH", "./yourweb_audit.jsonl"))
RUNTIME_SECRET_DIR = Path(os.getenv("YOURWEB_SECRET_DIR") or "/run/lisan/secrets")
READ_ONLY_UAPI = {
    ("DomainInfo", "list_domains"),
    ("DomainInfo", "domains_data"),
    ("Email", "list_pops"),
    ("Fileman", "get_file_information"),
    ("SSL", "installed_hosts"),
    ("SSL", "get_autossl_excluded_domains"),
    ("SSL", "get_autossl_problems"),
    ("SSL", "is_autossl_check_in_progress"),
}
READ_ONLY_API2 = {
    ("AddonDomain", "listaddondomains"),
    ("SSH", "listkeys"),
    ("SSH", "fetchkey"),
}
WRITE_UAPI = {
    ("SSL", "start_autossl_check"),
    ("SubDomain", "addsubdomain"),
    ("Email", "add_pop"),
}
WRITE_API2 = {
    ("AddonDomain", "deladdondomain"),
    ("Park", "park"),
    ("Park", "unpark"),
    ("SSH", "genkey"),
    ("SSH", "importkey"),
    ("SSH", "authkey"),
    ("SSH", "deletekey"),
}


def load_env_file(path: Path) -> None:
    if not path.is_file():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if not key:
            continue
        value = value.strip().strip("\"'")
        os.environ.setdefault(key, value)


def load_runtime_env() -> None:
    if str(RUNTIME_SECRET_DIR).strip() == "":
        return
    if not RUNTIME_SECRET_DIR.is_dir():
        return
    for env_file in sorted(RUNTIME_SECRET_DIR.glob("*.env")):
        load_env_file(env_file)


def env_value(*names: str) -> str:
    for name in names:
        value = (os.getenv(name) or "").strip()
        if value != "":
            return value
    return ""


def require_credentials() -> tuple[str, str, str]:
    load_runtime_env()
    host = env_value("LISAN_YOURWEB_CPANEL_HOST", "YOURWEB_CPANEL_HOST", "CPANEL_HOST")
    user = env_value("LISAN_YOURWEB_CPANEL_USER", "YOURWEB_CPANEL_USER", "CPANEL_USER")
    token = env_value("LISAN_YOURWEB_CPANEL_TOKEN", "YOURWEB_CPANEL_TOKEN", "CPANEL_TOKEN")
    if not host or not user or not token:
        raise RuntimeError(
            "Missing cPanel credentials. Provide LISAN_YOURWEB_CPANEL_HOST, "
            "LISAN_YOURWEB_CPANEL_USER, and LISAN_YOURWEB_CPANEL_TOKEN."
        )
    return host, user, token


def parse_key_values(items: list[str]) -> dict[str, str]:
    params: dict[str, str] = {}
    for item in items:
        if "=" not in item:
            raise ValueError(f"Expected key=value, got: {item}")
        key, value = item.split("=", 1)
        key = key.strip()
        if not key:
            raise ValueError(f"Invalid empty parameter name in: {item}")
        params[key] = value
    return params


def sanitize_params(params: dict[str, Any]) -> dict[str, Any]:
    redacted = {}
    for key, value in params.items():
        lower = key.lower()
        if any(token in lower for token in ("token", "password", "secret", "key")):
            redacted[key] = "[redacted]"
        else:
            redacted[key] = value
    return redacted


def ensure_write_allowed(kind: str, module: str, function: str, allow_write: bool) -> None:
    key = (module, function)
    read_only = READ_ONLY_UAPI if kind == "uapi" else READ_ONLY_API2
    write_ops = WRITE_UAPI if kind == "uapi" else WRITE_API2
    if key in read_only:
        return
    if key in write_ops:
        if not allow_write:
            raise RuntimeError(f"{module}::{function} is a mutating operation; rerun with --allow-write after approval.")
        return
    if not allow_write:
        raise RuntimeError(
            f"{module}::{function} is not in the read-only allowlist. "
            "Treat it as a write and rerun with --allow-write only after approval."
        )


def http_json(url: str, headers: dict[str, str]) -> tuple[int, Any]:
    request = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            status = int(response.status)
            body = response.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        status = int(exc.code)
        body = exc.read().decode("utf-8", errors="replace")
    try:
        parsed = json.loads(body)
    except json.JSONDecodeError:
        parsed = {"raw": body}
    return status, parsed


def call_uapi(host: str, user: str, token: str, module: str, function: str, params: dict[str, str]) -> dict[str, Any]:
    query = urllib.parse.urlencode(params, doseq=True)
    url = f"https://{host}:2083/execute/{module}/{function}"
    if query:
        url += "?" + query
    status, payload = http_json(url, {"Authorization": f"cpanel {user}:{token}"})
    return {
        "kind": "uapi",
        "host": host,
        "module": module,
        "function": function,
        "http_status": status,
        "params": sanitize_params(params),
        "payload": payload,
    }


def call_api2(host: str, user: str, token: str, module: str, function: str, params: dict[str, str]) -> dict[str, Any]:
    query = {
        "cpanel_jsonapi_user": user,
        "cpanel_jsonapi_apiversion": "2",
        "cpanel_jsonapi_module": module,
        "cpanel_jsonapi_func": function,
    }
    query.update(params)
    url = f"https://{host}:2083/json-api/cpanel?{urllib.parse.urlencode(query, doseq=True)}"
    status, payload = http_json(url, {"Authorization": f"cpanel {user}:{token}"})
    return {
        "kind": "api2",
        "host": host,
        "module": module,
        "function": function,
        "http_status": status,
        "params": sanitize_params(params),
        "payload": payload,
    }


def cmd_probe(_: argparse.Namespace) -> dict[str, Any]:
    load_runtime_env()
    host = env_value("LISAN_YOURWEB_CPANEL_HOST", "YOURWEB_CPANEL_HOST", "CPANEL_HOST")
    user = env_value("LISAN_YOURWEB_CPANEL_USER", "YOURWEB_CPANEL_USER", "CPANEL_USER")
    token = env_value("LISAN_YOURWEB_CPANEL_TOKEN", "YOURWEB_CPANEL_TOKEN", "CPANEL_TOKEN")
    return {
        "host": host,
        "user_present": user != "",
        "token_present": token != "",
        "runtime_secret_dir": str(RUNTIME_SECRET_DIR),
        "runtime_secret_dir_exists": RUNTIME_SECRET_DIR.is_dir(),
    }


def cmd_uapi(args: argparse.Namespace) -> dict[str, Any]:
    host, user, token = require_credentials()
    params = parse_key_values(args.param)
    ensure_write_allowed("uapi", args.module, args.function, args.allow_write)
    return call_uapi(host, user, token, args.module, args.function, params)


def cmd_api2(args: argparse.Namespace) -> dict[str, Any]:
    host, user, token = require_credentials()
    params = parse_key_values(args.param)
    ensure_write_allowed("api2", args.module, args.function, args.allow_write)
    return call_api2(host, user, token, args.module, args.function, params)


def run_uapi_read(module: str, function: str, params: dict[str, str] | None = None) -> dict[str, Any]:
    host, user, token = require_credentials()
    return call_uapi(host, user, token, module, function, params or {})


def run_api2_read(module: str, function: str, params: dict[str, str] | None = None) -> dict[str, Any]:
    host, user, token = require_credentials()
    return call_api2(host, user, token, module, function, params or {})


def cmd_head(args: argparse.Namespace) -> dict[str, Any]:
    request = urllib.request.Request(args.url, method="HEAD")
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            headers = dict(response.getheaders())
            status = int(response.status)
    except urllib.error.HTTPError as exc:
        headers = dict(exc.headers.items())
        status = int(exc.code)
    return {
        "url": args.url,
        "http_status": status,
        "headers": headers,
    }


def cmd_tls_check(args: argparse.Namespace) -> dict[str, Any]:
    context = ssl.create_default_context()
    with socket.create_connection((args.hostname, args.port), timeout=20) as sock:
        with context.wrap_socket(sock, server_hostname=args.hostname) as tls_sock:
            cert = tls_sock.getpeercert()
            cipher = tls_sock.cipher()
    san = []
    for entry in cert.get("subjectAltName", []):
        if len(entry) == 2:
            san.append({"type": entry[0], "value": entry[1]})
    subject = {}
    for rdn in cert.get("subject", []):
        for key, value in rdn:
            subject[key] = value
    issuer = {}
    for rdn in cert.get("issuer", []):
        for key, value in rdn:
            issuer[key] = value
    return {
        "hostname": args.hostname,
        "port": args.port,
        "subject": subject,
        "issuer": issuer,
        "not_before": cert.get("notBefore"),
        "not_after": cert.get("notAfter"),
        "subject_alt_name": san,
        "cipher": cipher,
    }


def cmd_start_autossl(args: argparse.Namespace) -> dict[str, Any]:
    if not args.allow_write:
        raise RuntimeError("start-autossl is a live mutation; rerun with --allow-write after approval.")
    return run_uapi_read("SSL", "start_autossl_check")


def cmd_audit_log(args: argparse.Namespace) -> dict[str, Any]:
    entry = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "operation": args.operation,
        "target": args.target,
        "endpoint": args.endpoint,
        "params": sanitize_params(parse_key_values(args.param)),
        "result": args.result,
        "summary": args.summary,
        "verification": args.verification,
    }
    path = Path(args.path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=True) + "\n")
    return {"ok": True, "path": str(path), "entry": entry}


def cmd_dig(args: argparse.Namespace) -> dict[str, Any]:
    command = ["dig", "+short", args.hostname]
    result = subprocess.run(command, capture_output=True, text=True, check=False, timeout=20)
    return {
        "hostname": args.hostname,
        "exit_code": result.returncode,
        "stdout": [line for line in result.stdout.splitlines() if line.strip()],
        "stderr": result.stderr.strip(),
    }


# ── SSH key management ─────────────────────────────────────────────────────


def cmd_ssh_list_keys(args: argparse.Namespace) -> dict[str, Any]:
    """List SSH keys on the cPanel account (read-only)."""
    params: dict[str, str] = {}
    if getattr(args, "key_type", None):
        params["types"] = args.key_type
    return run_api2_read("SSH", "listkeys", params)


def cmd_ssh_fetch_key(args: argparse.Namespace) -> dict[str, Any]:
    """Retrieve a specific SSH key by name (read-only)."""
    params: dict[str, str] = {"name": args.name}
    if getattr(args, "key_type", None):
        params["type"] = args.key_type
    return run_api2_read("SSH", "fetchkey", params)


def cmd_ssh_gen_key(args: argparse.Namespace) -> dict[str, Any]:
    """Generate a new SSH key pair on the cPanel server (write)."""
    if not args.allow_write:
        raise RuntimeError("ssh-gen-key is a mutating operation; rerun with --allow-write after approval.")
    host, user, token = require_credentials()
    params: dict[str, str] = {"name": args.name, "bits": str(args.bits)}
    if args.key_type:
        params["type"] = args.key_type
    if args.passphrase:
        params["password"] = args.passphrase
    return call_api2(host, user, token, "SSH", "genkey", params)


def cmd_ssh_import_key(args: argparse.Namespace) -> dict[str, Any]:
    """Import an existing SSH key into the cPanel account (write)."""
    if not args.allow_write:
        raise RuntimeError("ssh-import-key is a mutating operation; rerun with --allow-write after approval.")
    host, user, token = require_credentials()
    key_path = Path(args.key_file)
    if not key_path.is_file():
        raise RuntimeError(f"Key file not found: {key_path}")
    key_text = key_path.read_text(encoding="utf-8").strip()
    params: dict[str, str] = {"name": args.name, "key": key_text}
    if args.passphrase:
        params["password"] = args.passphrase
    return call_api2(host, user, token, "SSH", "importkey", params)


def cmd_ssh_authorize_key(args: argparse.Namespace) -> dict[str, Any]:
    """Authorize (or deauthorize) an SSH public key for login (write)."""
    if not args.allow_write:
        raise RuntimeError("ssh-authorize-key is a mutating operation; rerun with --allow-write after approval.")
    host, user, token = require_credentials()
    params: dict[str, str] = {
        "name": args.name,
        "authorize": "1" if args.authorize else "0",
    }
    return call_api2(host, user, token, "SSH", "authkey", params)


def cmd_ssh_delete_key(args: argparse.Namespace) -> dict[str, Any]:
    """Delete an SSH key from the cPanel account (write)."""
    if not args.allow_write:
        raise RuntimeError("ssh-delete-key is a mutating operation; rerun with --allow-write after approval.")
    host, user, token = require_credentials()
    params: dict[str, str] = {"name": args.name}
    if args.key_type:
        params["type"] = args.key_type
    return call_api2(host, user, token, "SSH", "deletekey", params)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="YourWeb cPanel helper")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("probe", help="Check whether cPanel secrets are available")

    uapi = subparsers.add_parser("uapi", help="Run one UAPI function")
    uapi.add_argument("--module", required=True)
    uapi.add_argument("--function", required=True)
    uapi.add_argument("--param", action="append", default=[], help="key=value")
    uapi.add_argument("--allow-write", action="store_true")

    api2 = subparsers.add_parser("api2", help="Run one API 2 function")
    api2.add_argument("--module", required=True)
    api2.add_argument("--function", required=True)
    api2.add_argument("--param", action="append", default=[], help="key=value")
    api2.add_argument("--allow-write", action="store_true")

    subparsers.add_parser("list-domains", help="Run DomainInfo::list_domains")
    subparsers.add_parser("domains-data", help="Run DomainInfo::domains_data")
    subparsers.add_parser("addon-list", help="Run AddonDomain::listaddondomains")
    subparsers.add_parser("list-mailboxes", help="Run Email::list_pops")

    file_info = subparsers.add_parser("file-info", help="Run Fileman::get_file_information")
    file_info.add_argument("--path", required=True, help="Remote path relative to the cPanel home")

    subparsers.add_parser("ssl-installed", help="Run SSL::installed_hosts")
    subparsers.add_parser("autossl-excluded", help="Run SSL::get_autossl_excluded_domains")
    subparsers.add_parser("autossl-problems", help="Run SSL::get_autossl_problems")
    subparsers.add_parser("autossl-status", help="Run SSL::is_autossl_check_in_progress")

    start_autossl = subparsers.add_parser("start-autossl", help="Run SSL::start_autossl_check")
    start_autossl.add_argument("--allow-write", action="store_true")

    # ── SSH key management ─────────────────────────────────────────────
    ssh_list = subparsers.add_parser("ssh-list-keys", help="List SSH keys on the account")
    ssh_list.add_argument("--key-type", default="", help="Filter by type (key, dsa); omit for all")

    ssh_fetch = subparsers.add_parser("ssh-fetch-key", help="Retrieve a specific SSH key")
    ssh_fetch.add_argument("--name", required=True, help="Key name (e.g. id_rsa)")
    ssh_fetch.add_argument("--key-type", default="", help="public or private")

    ssh_gen = subparsers.add_parser("ssh-gen-key", help="Generate a new SSH key pair on the server")
    ssh_gen.add_argument("--name", required=True, help="Key name (e.g. id_rsa)")
    ssh_gen.add_argument("--bits", type=int, default=4096, help="Key size in bits (default 4096)")
    ssh_gen.add_argument("--key-type", default="", help="rsa (default) or dsa")
    ssh_gen.add_argument("--passphrase", default="", help="Optional passphrase for the private key")
    ssh_gen.add_argument("--allow-write", action="store_true")

    ssh_import = subparsers.add_parser("ssh-import-key", help="Import an existing SSH key")
    ssh_import.add_argument("--name", required=True, help="Key name to store as")
    ssh_import.add_argument("--key-file", required=True, help="Path to the key file to import")
    ssh_import.add_argument("--passphrase", default="", help="Passphrase if the key is encrypted")
    ssh_import.add_argument("--allow-write", action="store_true")

    ssh_auth = subparsers.add_parser("ssh-authorize-key", help="Authorize or deauthorize an SSH key")
    ssh_auth.add_argument("--name", required=True, help="Key name to authorize")
    ssh_auth.add_argument("--deauthorize", action="store_true", help="Deauthorize instead of authorize")
    ssh_auth.add_argument("--allow-write", action="store_true")

    ssh_del = subparsers.add_parser("ssh-delete-key", help="Delete an SSH key")
    ssh_del.add_argument("--name", required=True, help="Key name to delete")
    ssh_del.add_argument("--key-type", default="", help="public, private, or omit for both")
    ssh_del.add_argument("--allow-write", action="store_true")

    head = subparsers.add_parser("head", help="Fetch public HTTP headers")
    head.add_argument("--url", required=True)

    tls = subparsers.add_parser("tls-check", help="Inspect the public TLS certificate")
    tls.add_argument("--hostname", required=True)
    tls.add_argument("--port", type=int, default=443)

    dig = subparsers.add_parser("dig", help="Run dig +short for a hostname")
    dig.add_argument("--hostname", required=True)

    audit = subparsers.add_parser("audit-log", help="Append a sanitized local audit entry")
    audit.add_argument("--operation", required=True)
    audit.add_argument("--target", required=True)
    audit.add_argument("--endpoint", required=True)
    audit.add_argument("--param", action="append", default=[], help="key=value")
    audit.add_argument("--result", required=True, choices=["success", "failure"])
    audit.add_argument("--summary", required=True)
    audit.add_argument("--verification", default="")
    audit.add_argument("--path", default=str(DEFAULT_AUDIT_PATH))

    return parser


def dispatch(args: argparse.Namespace) -> dict[str, Any]:
    if args.command == "probe":
        return cmd_probe(args)
    if args.command == "uapi":
        return cmd_uapi(args)
    if args.command == "api2":
        return cmd_api2(args)
    if args.command == "list-domains":
        return run_uapi_read("DomainInfo", "list_domains")
    if args.command == "domains-data":
        return run_uapi_read("DomainInfo", "domains_data")
    if args.command == "addon-list":
        return run_api2_read("AddonDomain", "listaddondomains")
    if args.command == "list-mailboxes":
        return run_uapi_read("Email", "list_pops")
    if args.command == "file-info":
        return run_uapi_read("Fileman", "get_file_information", {"path": args.path})
    if args.command == "ssl-installed":
        return run_uapi_read("SSL", "installed_hosts")
    if args.command == "autossl-excluded":
        return run_uapi_read("SSL", "get_autossl_excluded_domains")
    if args.command == "autossl-problems":
        return run_uapi_read("SSL", "get_autossl_problems")
    if args.command == "autossl-status":
        return run_uapi_read("SSL", "is_autossl_check_in_progress")
    if args.command == "start-autossl":
        return cmd_start_autossl(args)
    if args.command == "ssh-list-keys":
        return cmd_ssh_list_keys(args)
    if args.command == "ssh-fetch-key":
        return cmd_ssh_fetch_key(args)
    if args.command == "ssh-gen-key":
        return cmd_ssh_gen_key(args)
    if args.command == "ssh-import-key":
        return cmd_ssh_import_key(args)
    if args.command == "ssh-authorize-key":
        args.authorize = not getattr(args, "deauthorize", False)
        return cmd_ssh_authorize_key(args)
    if args.command == "ssh-delete-key":
        return cmd_ssh_delete_key(args)
    if args.command == "head":
        return cmd_head(args)
    if args.command == "tls-check":
        return cmd_tls_check(args)
    if args.command == "dig":
        return cmd_dig(args)
    if args.command == "audit-log":
        return cmd_audit_log(args)
    raise RuntimeError(f"Unknown command: {args.command}")


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        payload = dispatch(args)
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, indent=2))
        return 1
    print(json.dumps({"ok": True, "result": payload}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
