---
name: yourweb-cpanel
description: Safely inspect and administer a YourWeb-style cPanel hosting account. Use when working with cPanel UAPI or API 2 calls, domain setup/removal, mailbox administration, AutoSSL checks, file deployment verification, or public DNS/HTTPS validation for a hosted site.
---

# YourWeb cPanel

Use this skill for YourWeb or other cPanel-hosted site work that needs API
access plus separate verification of DNS, HTTP, and TLS.

## Secret Model

Read credentials from your local environment or secret store, not from ad hoc
files or chat:

- `YOURWEB_CPANEL_HOST`
- `YOURWEB_CPANEL_USER`
- `YOURWEB_CPANEL_TOKEN`

The helper script can also honor compatible fallback names such as
`CPANEL_HOST`, `CPANEL_USER`, and `CPANEL_TOKEN`. Never print the token, never
paste a full authenticated curl command into chat, and never write the token
into an audit log.

## Required Operating Sequence

For any live change:

1. Confirm the exact target and whether the request is read-only or mutating.
2. Discover current state with read-only calls first.
3. Summarize the exact mutation: endpoint, sanitized parameters, expected effect,
   and verification plan.
4. Get explicit approval for that narrow mutation.
5. Execute one mutation at a time.
6. Verify with a separate read call.
7. Verify public behavior separately when relevant.
8. Record an audit entry.

If the API returns an error or unexpected schema, stop. Do not retry blindly.

## Helper Script

Use `scripts/yourweb_cpanel.py` for deterministic calls:

- `probe` checks whether the vault-backed credentials are available.
- `list-domains`, `domains-data`, `addon-list`, `list-mailboxes`,
  `file-info`, `ssl-installed`, `autossl-excluded`, `autossl-problems`,
  and `autossl-status` are read-only discovery helpers.
- `uapi` and `api2` support one-off calls.
- `start-autossl` is a bundled mutation helper and requires `--allow-write`.
- `ssh-list-keys` and `ssh-fetch-key` are read-only SSH key discovery.
- `ssh-gen-key`, `ssh-import-key`, `ssh-authorize-key`, and `ssh-delete-key`
  are SSH key write operations (each requires `--allow-write`).
- `head` and `tls-check` verify the public site separately from cPanel state.
- `audit-log` appends a sanitized JSONL entry to a configurable local audit
  file.

Examples:

```bash
python3 scripts/yourweb_cpanel.py probe
python3 scripts/yourweb_cpanel.py list-domains
python3 scripts/yourweb_cpanel.py domains-data
python3 scripts/yourweb_cpanel.py file-info --path public_html/example.com/index.html
python3 scripts/yourweb_cpanel.py head --url https://example.com/
python3 scripts/yourweb_cpanel.py tls-check --hostname example.com
python3 scripts/yourweb_cpanel.py start-autossl --allow-write
```

SSH key provisioning workflow (generate, authorize, fetch):

```bash
# 1. List existing keys (read-only)
python3 scripts/yourweb_cpanel.py ssh-list-keys

# 2. Generate a new 4096-bit RSA key pair on the server
python3 scripts/yourweb_cpanel.py ssh-gen-key --name id_rsa --bits 4096 --allow-write

# 3. Authorize the public key for SSH login
python3 scripts/yourweb_cpanel.py ssh-authorize-key --name id_rsa --allow-write

# 4. Retrieve the private key to save locally
python3 scripts/yourweb_cpanel.py ssh-fetch-key --name id_rsa --key-type private
```

Import an existing key instead of generating one:

```bash
python3 scripts/yourweb_cpanel.py ssh-import-key \
  --name id_rsa --key-file ~/.ssh/id_rsa.pub --allow-write
```

Remove a key:

```bash
python3 scripts/yourweb_cpanel.py ssh-delete-key --name id_rsa --allow-write
```

Deauthorize without deleting:

```bash
python3 scripts/yourweb_cpanel.py ssh-authorize-key --name id_rsa --deauthorize --allow-write
```

Generic UAPI call with sanitized parameters:

```bash
python3 scripts/yourweb_cpanel.py \
  uapi --module DomainInfo --function list_domains
```

Generic API 2 call:

```bash
python3 scripts/yourweb_cpanel.py \
  api2 --module AddonDomain --function listaddondomains
```

## Safety Rules

- Treat functions outside the helper's read-only allowlist as write-capable.
- Pass `--allow-write` only after approval for that exact action.
- Keep writes serialized; do not batch multiple independent mutations together.
- Do not create or advertise `www` by default. Only do that if explicitly
  required and approved.
- DNS writes are not reliable on this platform. Prefer describing the needed
  record and having it changed in the UI or the external DNS provider.
- “Files uploaded” is not the same as “site works over HTTPS.” Verify both.

## References

Read `references/source-guide.md` when you need the fuller operating guide. It
contains generalized YourWeb/cPanel account behaviors, mutation sequences, and
failure handling details adapted for reuse.

## Backend status

This skill currently operates the mature legacy Lisan backend under `/var/www`. Keep those paths unchanged until the corresponding capability is migrated into the new Lisan runtime.
