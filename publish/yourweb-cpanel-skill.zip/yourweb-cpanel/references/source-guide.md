# YourWeb cPanel Operations Guide for AI Agents

Adapted into a reusable distribution on 2026-08-11. When this reference
conflicts with live cPanel behavior, prefer a fresh read-only probe and record
the newer verified behavior.

## 1. Identity, endpoint, and authentication

- Platform: YourWeb or other standard cPanel hosting environment.
- Host: your configured cPanel host, for example `yourweb.example.edu`.
- UAPI base: `https://<cpanel-host>:2083/execute/`.
- API 2 base: `https://<cpanel-host>:2083/json-api/cpanel`.
- Authentication: cPanel API token, not OAuth and not a cPanel password.
- Header shape: `Authorization: cpanel ${CPANEL_USER}:${CPANEL_TOKEN}`.

Use environment variables such as `CPANEL_USER` and `CPANEL_TOKEN`. Never
print, echo, persist, or include the token in an audit record. The token is
effectively full-account privilege because cPanel tokens are not narrowly
scoped.

For a request, construct the URL and sanitized parameters separately. Do not
display the complete authenticated command. Use HTTPS only.

## 2. Important domain naming policy

The default setup is the bare domain only. Do not create, configure, advertise,
or redirect a `www` subdomain unless the user explicitly asks for it or a
specific provider requirement is confirmed and explained.

Examples:

- Default: `example.com`.
- Not automatic: `www.example.com`.
- Default document root: `public_html/example.com`.

Some AutoSSL runs on this account have been more reliable when a `www` DNS
record exists. That is an environment limitation, not a default naming policy.
If certificate issuance requires it, explain the requirement and ask the user to
approve or manually create the record. Never silently add `www` merely because a
certificate workflow mentions it.

## 3. Hermes capabilities to use

There is no dedicated YourWeb API tool. Use the agent's normal capabilities:

- terminal: issue carefully constructed `curl`, `dig`, `openssl`, and local
  audit commands;
- file tools: inspect local site files and prepare deployment artifacts;
- browser: verify the rendered public site and interactive behavior;
- web/network tools: check public DNS and HTTP reachability;
- memory/session tools: recall prior account-specific findings, but do not
  treat old claims as current state;
- clarification/approval: summarize live writes and obtain explicit
  confirmation;
- task/delegation tools: delegate independent read-only checks when useful, but
  keep all live writes serialized and centrally verified.

The cPanel API itself is the tool boundary. Prefer one documented API call at a
time over a large unverified script.

## 4. Required operating sequence

### Before any live write

1. Confirm the exact target: domain, mailbox, file path, DNS zone,
   certificate host, or SSH key.
2. Confirm whether the request is read-only or includes a live change.
3. Confirm credentials are available without exposing them.
4. Discover current state with read-only calls.
5. Identify the exact document root and any existing conflicting resource.
6. Summarize the proposed mutation in plain language:
   - resource being changed;
   - endpoint/function;
   - parameters, excluding secrets;
   - expected effect;
   - verification step.
7. Wait for explicit approval unless the user already approved that exact
   narrow action in the current conversation.

### After each mutation

1. Inspect the raw non-secret API result.
2. Verify the result with a separate read call.
3. For websites, verify the public response and TLS separately.
4. For mail, verify the mailbox and then perform an SMTP test if requested.
5. Write a local audit entry containing timestamp, operation, target,
   endpoint, sanitized parameters, and result summary.

If an API returns an error, unexpected schema, or ambiguous result: stop,
capture the non-secret error, report it, and do not retry blindly.

## 5. Read-only discovery functions

Use these before mutations whenever applicable:

- `DomainInfo::list_domains`
- `DomainInfo::domains_data`
- API 2 `AddonDomain::listaddondomains`
- `Email::list_pops`
- `Fileman::get_file_information`
- `SSL::installed_hosts`
- `SSL::get_autossl_excluded_domains`
- `SSL::get_autossl_problems`
- `SSL::is_autossl_check_in_progress`
- public `dig`
- `curl -I https://domain`
- `openssl s_client -connect domain:443 -servername domain`

Never guess the internal subdomain mapping needed by API 2 domain deletion.
Discover it first.

## 6. Domain setup

For a new domain or subdomain, use UAPI `SubDomain::addsubdomain`.

Typical parameter shape:

- `domain`: requested bare domain or subdomain label;
- `rootdomain`: existing account context, such as the account's YourWeb
  hostname;
- `dir`: document root, normally `public_html/<bare-domain>`.

DNS pointing is separate from cPanel registration. Verify both independently. A
domain can exist in cPanel while public DNS is wrong, or public DNS can point
correctly while the domain is absent from cPanel.

Do not declare setup complete until the domain exists, the expected document
root exists, public content is reachable, and HTTPS has been separately
verified.

## 7. Static site deployment

Use `Fileman::upload_files` with multipart form data. Use `overwrite=1` only
when replacing files is intended.

Expected fields:

- `dir`: remote path relative to the cPanel home;
- `overwrite=1`;
- one `file-N` field per file, with the correct MIME type.

Deployment verification order:

1. `Fileman::get_file_information` for every uploaded file;
2. fetch the public page and confirm the expected content;
3. validate TLS separately;
4. if the site uses HTMX or fragments, fetch one fragment directly and verify
   the browser interaction changes the target panel;
5. verify favicon/logo assets and check the browser console for errors.

Report deployment and TLS separately. “Files deployed” does not mean “the
public HTTPS site is fully correct.”

## 8. Mailbox management

Create mailboxes with `Email::add_pop`.

Required concepts:

- local part;
- hosted domain;
- strong random password;
- explicit quota in MB.

Never place mailbox passwords in logs or ordinary chat. Verify the mailbox with
`Email::list_pops`.

For a requested SMTP test, use the supplied `SMTP_HOST`, `SMTP_PORT`,
`SMTP_USER`, `SMTP_PASSWORD`, and `RECIPIENT_EMAIL` environment variables with
a local script. Use TLS, authenticate, send one test message, and report only
the delivery result and non-secret error.

After mail DNS is configured, inspect SPF, DKIM, and DMARC at the receiving
destination when possible. Do not claim mail authentication is correct based
only on cPanel API success.

## 9. DNS management

DNS management on this YourWeb account is unreliable. Before attempting any
cPanel DNS write, determine whether the zone is actually authoritative in cPanel
and whether the needed function exists on this server.

Known limitations:

- `DNS::fetch_zone_records` is unavailable;
- `DNS::mass_edit_zone` exists but requires a serial that cannot reliably be
  fetched;
- high-level DMARC repair functions are unavailable.

The safe default is to explain the required DNS record and have the user change
it in the cPanel UI or external DNS provider. Do not attempt repeated API
writes when the server reports a missing or unusable DNS function.

## 10. Domain removal

Addon-domain removal requires the older API 2 function
`AddonDomain::deladdondomain`.

Required values include:

- public addon domain;
- mapped internal subdomain in underscore form.

Safe sequence:

1. discover the mapping with `DomainInfo::domains_data` or API 2
   `AddonDomain::listaddondomains`;
2. obtain a separate confirmation naming the exact domain;
3. remove it with API 2;
4. verify with `DomainInfo::list_domains` and `DomainInfo::domains_data`;
5. check `Email::list_pops` because domain mailboxes may disappear;
6. separately verify whether document-root files remain.

Deletion can leave stale internal DNS records. Wait two to five minutes before
attempting to recreate the same domain. Never immediately loop on an “entry
already exists” error.

## 11. Parked-domain conversion

When a parked alias must become its own site:

1. discover the current mapping;
2. use API 2 `Park::unpark`;
3. create the underlying document root with UAPI `SubDomain::addsubdomain`;
4. use API 2 `Park::park` to attach the public domain;
5. verify with `DomainInfo::list_domains`, `DomainInfo::domains_data`, and
   `Fileman::get_file_information`.

Do not assume `SubDomain::addsubdomain` alone creates the final public
addon-domain representation.

## 12. SSL / AutoSSL

Use the following read-check / mutation / verify sequence:

1. `SSL::installed_hosts`;
2. `SSL::get_autossl_excluded_domains`;
3. `SSL::get_autossl_problems`;
4. `SSL::start_autossl_check`;
5. poll `SSL::is_autossl_check_in_progress` until idle;
6. re-check `SSL::installed_hosts`;
7. verify the public host with `curl` and `openssl`.

AutoSSL can fail even when public DNS looks correct. After one or two failed
attempts, stop retrying and report the server-side issue for manual
hosting-provider intervention. A certificate for an internal YourWeb hostname
is not proof that the public domain is covered.

The `SSL::toggle_https_redirect` function is not available on this instance. If
no `.htaccess` rule explains a redirect, it may be enforced at the server
level.

## 13. SSH key administration

SSH key management may use API 2 functions such as `SSH::importkey` and
`SSH::authkey`. Treat key generation and authorization as live security changes
requiring explicit approval.

Verify the API result, then test SSH separately. Do not claim a key works
because cPanel reported that it was imported or authorized. This account's
Fileman API cannot reliably inspect `~/.ssh/authorized_keys` or permissions.

## 14. Audit logging

For each live operation, record locally:

- timestamp;
- operation name;
- exact target;
- endpoint and function;
- sanitized parameters;
- success/failure;
- short response summary;
- verification result.

Never record:

- API tokens;
- mailbox passwords;
- full authenticated curl commands;
- private keys;
- secrets copied from tool output.

## 15. Common failure handling

- Missing API function: stop and report the function name.
- Unexpected response schema: stop and inspect manually.
- Stale DNS after deletion: wait two to five minutes; do not loop.
- AutoSSL failure: inspect DCV problems once or twice, then escalate.
- SSH authentication failure: distinguish API authorization from actual SSH
  login.
- HTTP content works but TLS is wrong: report successful content deployment and
  separate certificate failure.
- Public DNS does not match: treat external DNS as a separate dependency.
- `www` is missing: do not create it by default; mention it only if the
  specific certificate or user request requires it.

## 16. Final completion standard

Before saying a task is complete, verify the actual result rather than trusting
a tool’s success flag. For a domain/site task, the minimum evidence is:

- cPanel state matches the requested resource;
- target document root and files exist;
- public content is reachable;
- TLS hostname and SAN coverage are correct;
- any DNS propagation uncertainty is stated;
- local audit entry exists.

For mail, additionally verify the mailbox and SMTP delivery. For SSH,
additionally verify an actual login. If any required verification is
unavailable, say exactly what was and was not verified.

## 17. Source material and maintenance

The source skill was maintained locally under Hermes as
`productivity/yourweb-cpanel`. The live cPanel UAPI documentation at
`https://api.docs.cpanel.net/` is authoritative when this guide conflicts with
older notes. Account-specific behavior should be updated only after a real
read-only probe or verified operation, with the date and evidence recorded.
